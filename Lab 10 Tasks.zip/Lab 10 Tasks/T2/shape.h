#pragma once
class shape
{
private:
	char* color;
public:
	shape(const char* );
	void setcolor(const char*);
	const char* getcolor()const;
	void display()const;
};

