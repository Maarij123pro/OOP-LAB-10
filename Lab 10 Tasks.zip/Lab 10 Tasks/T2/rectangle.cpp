#include "rectangle.h"
#include<iostream>
using namespace std;
rectangle::rectangle(const char* c, int s, double l, double w):shape(c),shape2d(c,s)
{
	len = l;
	wid = w;
}
void rectangle::setlen(double l)
{
	len = l;
}
void rectangle::setwid(double w)
{
	wid = w;
}
double rectangle::getlen()const
{
	return len;
}
double rectangle::getwid()const
{
	return wid;
}
double rectangle::calculatearea()
{
	double area = len * wid;
	return area;
}
double rectangle::calculateperimeter()
{
	double perimeter = 2 * (len + wid);
	return perimeter;
}
void rectangle::display()
{
	shape::display();
	shape2d::display();
	cout << "The length of rectangle is:" << len << endl;
	cout << "The width of the rectangle is:" << wid << endl;
	cout << "The area is:" << calculatearea() << endl;
	cout << "The perimeter is:" << calculateperimeter() << endl;
}
