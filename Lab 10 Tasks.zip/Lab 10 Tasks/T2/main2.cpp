//#include<iostream>
//#include"rectangle.h"
//using namespace std;
//int main()
//{
//	rectangle r1("Red", 4, 1.3, 1.56);
//	r1.display();
//	return 0;
//}