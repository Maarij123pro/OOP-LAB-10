#include "shape2d.h"
#include<iostream>
using namespace std;
shape2d::shape2d(const char*c,int s):shape(c)
{
	sides = s;
}
void shape2d::setsides(int s)
{
	sides = s;
}
int shape2d::getsides()const
{
	return sides;
}
void shape2d::display()const
{
	cout << "The number of sides of this 2d shape are:" << sides << endl;
}
