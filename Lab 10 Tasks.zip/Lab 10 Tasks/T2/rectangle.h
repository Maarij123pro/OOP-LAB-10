#pragma once
#include"shape.h"
#include"shape2d.h"
class rectangle:public shape,public shape2d
{
private:
	double len;
	double wid;
public:
	rectangle(const char*, int, double, double);
	void setlen(double);
	void setwid(double);
	double getlen()const;
	double getwid()const;
	double calculatearea();
	double calculateperimeter();
	void display();
};

