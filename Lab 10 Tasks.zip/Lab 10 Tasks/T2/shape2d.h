#pragma once
#include"shape.h"
class shape2d:public shape
{
private:
	int sides;
public:
	shape2d(const char*,int);
	void setsides(int);
	int getsides()const;
	void display()const;
};

