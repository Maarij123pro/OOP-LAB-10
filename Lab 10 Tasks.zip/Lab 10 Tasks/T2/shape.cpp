#include "shape.h"
#include<cstring>
#include<iostream>
using namespace std;
shape::shape(const char* c)
{
	color = new char[strlen(c) + 1];
	strcpy_s(color, strlen(c) + 1, c);
}
void shape::setcolor(const char* c)
{
	color = new char[strlen(c) + 1];
	strcpy_s(color, strlen(c) + 1, c);
}
const char* shape::getcolor()const
{
	return color;
}
void shape::display()const
{
	cout << "The colour of the shape is:" << color << endl;
}