#pragma once
#include"vehicle.h"
#include"roadvehicle.h"
class car:public vehicle,public roadvehicle
{
private:
	char* color;
	int miles;
public:
	car(int, const char*, int, const char*, const char*, int);
	void setcolor(const char*);
	void setmiles(int);
	const char* getcolor()const;
	int getmiles()const;
	void display()const;
};

