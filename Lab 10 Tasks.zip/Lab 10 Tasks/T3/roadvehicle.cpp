#include "roadvehicle.h"
#include<cstring>
#include<iostream>
using namespace std;
roadvehicle::roadvehicle(int n, const char* ft)
{
	now = n;
	int len = strlen(ft) + 1;
	strcpy_s(fueltype, len, ft);
}
void roadvehicle::setnow(int n)
{
	now = n;
}
void roadvehicle::setfueltype(const char* ft)
{
	delete[] fueltype;
	int len = strlen(ft) + 1;
	strcpy_s(fueltype, len, ft);
}
const char* roadvehicle::getfueltype()const
{
	return fueltype;
}
int roadvehicle::getnow()const
{
	return now;
}
void roadvehicle::display()const
{
	cout << "The number of tyres are:" << now << endl;
	cout << "The type of fuel is:" << fueltype << endl;
}
