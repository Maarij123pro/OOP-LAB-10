#pragma once
class vehicle
{
private:
	int regno;
	char* brand;
public:
	vehicle(int, const char*);
	void setregno(int);
	void setbrand(const char*);
	int getregno()const;
	const char* getbrand()const;
	void display()const;
};

