#include"car.h"
#include<iostream>
using namespace std;
int main()
{
	car c1(123, "Civic", 4, "petrol", "White", 0);
	cout << "Displaying through Gettters:-" << endl << endl;
	c1.getbrand();
	c1.getregno();
	c1.getnow();
	c1.getfueltype();
	c1.getcolor();
	c1.getmiles();
	return 0;
}