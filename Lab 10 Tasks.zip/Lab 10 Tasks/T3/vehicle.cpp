#include "vehicle.h"
#include<cstring>
#include<iostream>
using namespace std;
vehicle::vehicle(int reg, const char* b)
{
	regno = reg;
	int len = strlen(b) + 1;
	brand = new char[len];
	strcpy_s(brand, len, b);
}
void vehicle::setbrand(const char* b)
{
	delete[] brand;
	int len = strlen(b) + 1;
	brand = new char[len];
	strcpy_s(brand, len, b);
}
void vehicle::setregno(int reg)
{
	regno = reg;
}
int vehicle::getregno()const
{
	return regno;
}
const char* vehicle::getbrand()const
{
	return brand;
}
void vehicle::display()const
{
	cout << "The brand name is:" << brand << endl;
	cout << "The regno is:" << regno << endl;
}