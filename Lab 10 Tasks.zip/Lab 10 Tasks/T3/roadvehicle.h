#pragma once
class roadvehicle
{
private:
	int now;
	char* fueltype;
public:
	roadvehicle(int, const char*);
	void setnow(int);
	void setfueltype(const char*);
	int getnow()const;
	const char* getfueltype()const;
	void display()const;

};

