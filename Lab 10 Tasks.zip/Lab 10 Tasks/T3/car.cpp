#include "car.h"
#include<iostream>
#include<cstring>
using namespace std;
car::car(int reg, const char* b, int n, const char* ft, const char* c, int m):vehicle(reg,b),roadvehicle(n,ft)
{
	int len = strlen(c) + 1;
	color = new char[len];
	strcpy_s(color, len, c);
	miles = m;
}
void car::setcolor(const char* c)
{
	delete[] color;
	int len = strlen(c) + 1;
	color = new char[len];
	strcpy_s(color, len, c);
}
void car::setmiles(int m)
{
	miles = m;
}
const char* car::getcolor()const
{
	return color;
}
int car::getmiles()const
{
	return miles;
}
void car::display()const
{
	vehicle::display();
	roadvehicle::display();
	cout << "The colour of the car is:" << color << endl;
	cout << "The number of miles the car is driven is:" << miles << endl;
}