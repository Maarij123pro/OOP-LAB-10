#include "electronicdevice.h"
#include<cstring>
#include<iostream>
using namespace std;
electronicdevice::electronicdevice()
{
	brand = new char[10];
	strcpy_s(brand, 10, "Unknown");
	warentyperiod = 0;
}
electronicdevice::electronicdevice(const char* b, int wp)
{
	warentyperiod = wp;
	int len = strlen(b) + 1;
	brand = new char[len];
	strcpy_s(brand, len, b);
}
void electronicdevice::setbrand(const char* b)
{
	delete[] brand;
	int len = strlen(b) + 1;
	brand = new char[len];
	strcpy_s(brand, len, b);
}
void electronicdevice::setwarrenty(int wp)
{
	warentyperiod = wp;
}
const char* electronicdevice::getbrand()const
{
	return brand;
}
int electronicdevice::getwarrenty()const
{
	return warentyperiod;
}
void electronicdevice::display()const
{
	cout << "The brand name is:" << brand << endl;
	cout << "The warrenty Period is:" << warentyperiod << endl;
}