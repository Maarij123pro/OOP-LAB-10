#include "smartphone.h"
#include<iostream>
using namespace std;
smartphone::smartphone():smartdevice(),electronicdevice()
{
	storagecapacity = 0;
	cameraresolution = 0.0;
	price = 0.0;
}
smartphone::smartphone(const char* b, int wp, bool sb, int sc, float cr, double p) :electronicdevice(b, wp), smartdevice(b,wp,sb)
{
	storagecapacity = sc;
	cameraresolution = cr;
	price = p;
}
void smartphone::setstoragecapacity(int sc)
{
	storagecapacity = sc;
}
void smartphone::setcameraresolution(float cr)
{
	cameraresolution = cr;
}
void smartphone::setprice(double p)
{
	price = p;
}
int smartphone::getstoragecapacity()const
{
	return storagecapacity;
}
float smartphone::getcameraresolution()const
{
	return cameraresolution;
}
double smartphone::getprice()const
{
	return price;
}
void smartphone::display()const
{
	electronicdevice::display();
	smartdevice::display();
	cout << "The storage capacity is:" << storagecapacity << endl;
	cout << "The camera resolution is:" << cameraresolution << endl;
	cout << "The price of the phone is:" << price << endl;
}
