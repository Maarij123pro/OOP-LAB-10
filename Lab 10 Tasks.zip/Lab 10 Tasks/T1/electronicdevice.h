#pragma once
class electronicdevice
{
private:
	char* brand;
	int warentyperiod;
public:
	electronicdevice();
	electronicdevice(const char*, int);
	void setbrand(const char*);
	void setwarrenty(int);
	const char* getbrand()const;
	int getwarrenty()const;
	void display()const;
};

