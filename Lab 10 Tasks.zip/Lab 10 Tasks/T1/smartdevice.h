#pragma once
#include"electronicdevice.h"
class smartdevice:public electronicdevice
{
private:
	bool supportbattery;
public:
	smartdevice();
	smartdevice(const char*, int, bool);
	void setbattery(bool);
	bool getbattery()const;
	void display()const;
};

