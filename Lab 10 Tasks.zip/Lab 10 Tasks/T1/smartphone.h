#pragma once
#include"electronicdevice.h"
#include"smartdevice.h"
class smartphone:public electronicdevice, public smartdevice
{
private:
	int storagecapacity;
	float cameraresolution;
	double price;
public:
	smartphone();
	smartphone(const char*, int, bool, int, float, double);
	void setstoragecapacity(int);
	void setcameraresolution(float);
	void setprice(double);
	int getstoragecapacity()const;
	float getcameraresolution()const;
	double getprice()const;
	void display()const;
};

