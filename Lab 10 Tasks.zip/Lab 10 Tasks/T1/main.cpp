#include"smartphone.h"
#include<iostream>
using namespace std;
int main()
{
    smartphone phone("Apple", 1, true, 256, 48.0f, 1199.99);
    phone.display();
	return 0;
}