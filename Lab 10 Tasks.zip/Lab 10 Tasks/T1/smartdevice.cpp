#include "smartdevice.h"
#include<iostream>
using namespace std;
smartdevice::smartdevice():electronicdevice()
{
	supportbattery = 0;
}
smartdevice::smartdevice(const char* b, int wp, bool sp) : electronicdevice(b, wp)
{
	supportbattery = sp;
}
void smartdevice::setbattery(bool sp)
{
	supportbattery = sp;
}
bool smartdevice::getbattery()const
{
	return supportbattery;
}
void smartdevice::display()const
{
	cout << "The device supports battery:" << supportbattery << endl;
}